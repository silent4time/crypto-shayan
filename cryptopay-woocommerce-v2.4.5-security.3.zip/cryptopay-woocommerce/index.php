<?php defined('ABSPATH') || exit;

/**
 * Plugin Name: CryptoPay WooCommerce
 * Version:     2.4.5-security.3
 * Plugin URI:  https://cryptopay-woocommerce.beycanpress.com/
 * Description: Payment plugin with her cryptocurrency wallet for WooCommerce
 * Author: BeycanPress
 * Author URI:  https://www.beycanpress.com
 * License:     GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.tr.html
 * Text Domain: cryptopay
 * Domain Path: /languages
 * Tags: Cryptopay, Cryptocurrency, WooCommerce, WordPress, MetaMask, Trust, Binance, Wallet, Ethereum, Bitcoin, Binance smart chain, Payment, Plugin, Gateway
 * Requires at least: 5.0
 * Tested up to: 6.2
 * Requires PHP: 7.4
*/

/**
 * ============================================================
 *  به‌روزرسانی خودکار از روی گیت‌هاب (GitHub Releases)
 * ============================================================
 * از این پس، هر بار که یک Release جدید با تگ نسخه‌ی بالاتر
 * (مثلاً v2.4.5-security.3) روی مخزن گیت‌هاب زیر منتشر بشه،
 * وردپرس همون‌طوری که برای افزونه‌های wordpress.org عمل می‌کنه،
 * توی صفحه‌ی «افزونه‌ها» اطلاع «نسخه جدید موجود است» رو نشون
 * می‌ده و دکمه‌ی «Update now» رو هم فعال می‌کنه (نصب مستقیم،
 * بدون نیاز به آپلود دستی zip).
 *
 * ⚠️ اگر اسم مخزن گیت‌هاب رو چیزی غیر از مقدار پیش‌فرض زیر
 * گذاشتی، فقط همین یک خط رو با آدرس واقعی مخزن خودت جایگزین کن:
 */
$cryptopaySecurityForkRepoUrl = 'https://github.com/silent4time/cryptopay-woocommerce-git/';

if (file_exists(__DIR__ . '/libs/plugin-update-checker/plugin-update-checker.php')) {
    require_once __DIR__ . '/libs/plugin-update-checker/plugin-update-checker.php';

    $cryptopayUpdateChecker = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
        $cryptopaySecurityForkRepoUrl,
        __FILE__,
        'cryptopay-woocommerce'
    );

    // آپدیت رو از روی "Releases" گیت‌هاب بخون (نه صرفاً تگ‌ها) و فایل zip
    // پیوست‌شده به هر ریلیز (مثلاً cryptopay-woocommerce-v2.4.5-security.2.zip)
    // رو مستقیماً به‌عنوان بسته‌ی نصب استفاده کن.
    $cryptopayUpdateChecker->getVcsApi()->enableReleaseAssets();

    // اگر مخزن گیت‌هاب Private باشه، یک Personal Access Token با
    // دسترسی خواندن (repo) بذار تا وردپرس بتونه ریلیزها رو ببینه:
    // $cryptopayUpdateChecker->setAuthentication('YOUR_GITHUB_TOKEN');
}

add_action('admin_footer', function() {
	if (!get_option('cryptopay_new_version_promotionx')) {
    	update_option('cryptopay_new_version_promotionx', true);
        ?>
        <div class="cp-video-modal">
            <div class="modal-content">
                <div class="close-btn">
                    X
                </div>
                <div>
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/3vaoFL4XG10" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                    <div class="buttons">
                        <a href="https://bit.ly/cplitebuynow" target="_blank" class="button"><?php echo __('Buy premium', 'cryptopay'); ?></a>
                        <a href="https://bit.ly/3pOiY25" target="_blank" class="button"><?php echo __('Review now', 'cryptopay'); ?></a>
                    </div>
                </div>
            </div>
        </div>
        <style>
            .cp-video-modal {
                position: fixed;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
                z-index: 999999;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .cp-video-modal .modal-content  {
                width: auto;
                max-width: 100%;
                padding: 40px;
                background-color: #fff;
                position: relative;
            }
            .cp-video-modal .modal-content .close-btn {
                position: absolute;
                right: 10px;
                top: 10px;
                cursor: pointer;
                font-weight: 600;
                font-size: 20px;
                color: #000;
            }
            .cp-video-modal .modal-content .buttons {
                position: relative;
                display: flex;
                justify-content: space-between;
                margin-top: 20px;
            }
            .cp-video-modal .modal-content iframe {
                max-width: 100%;
            }
        </style>
        <script>
            jQuery(document).ready(function($) {
                $('.cp-video-modal .close-btn').click(function() {
                    $('.cp-video-modal').hide();
                });
            });
        </script>
        <?php
	}
});
require __DIR__ . '/vendor/autoload.php';
new \BeycanPress\CryptoPay\WooCommerce\Loader(__FILE__);