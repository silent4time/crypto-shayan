<?php defined('ABSPATH') || exit;

/**
 * Plugin Name: Crypto Shayan | درگاه پرداخت ارزی شایان
 * Version:     1.2.0
 * Plugin URI:  https://github.com/silent4time/crypto-shayan/
 * Description: درگاه پرداخت ارز دیجیتال (کیف‌پول‌های MetaMask، Trust Wallet، Binance Wallet و WalletConnect) برای ووکامرس
 * Author:      Crypto Shayan
 * Author URI:  https://github.com/silent4time/crypto-shayan/
 * License:     GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.tr.html
 * Text Domain: crypto-shayan
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.2
 * Requires PHP: 7.4
 *
 * این افزونه بر پایه‌ی نسخه‌ی رایگان (Lite) افزونه‌ی متن‌باز CryptoPay
 * WooCommerce (توسعه‌دهنده‌ی اصلی: BeycanPress، لایسنس GPLv3) ساخته
 * شده و با نام و برندینگ Crypto Shayan بازتوزیع می‌شود؛ جزئیات در LICENSE.
*/

/**
 * ============================================================
 *  به‌روزرسانی خودکار از روی گیت‌هاب (GitHub Releases)
 * ============================================================
 * از این پس، هر بار که یک Release جدید با تگ نسخه‌ی بالاتر
 * (مثلاً v1.0.1) روی مخزن گیت‌هاب زیر منتشر بشه، وردپرس همون‌طوری
 * که برای افزونه‌های wordpress.org عمل می‌کنه، توی صفحه‌ی
 * «افزونه‌ها» اطلاع «نسخه جدید موجود است» رو نشون می‌ده و دکمه‌ی
 * «Update now» رو هم فعال می‌کنه (نصب مستقیم، بدون نیاز به آپلود
 * دستی zip).
 *
 * ⚠️ اگر اسم مخزن گیت‌هاب رو چیزی غیر از مقدار پیش‌فرض زیر
 * گذاشتی، فقط همین یک خط رو با آدرس واقعی مخزن خودت جایگزین کن:
 */
$cryptoShayanRepoUrl = 'https://github.com/silent4time/crypto-shayan/';

if (file_exists(__DIR__ . '/libs/plugin-update-checker/plugin-update-checker.php')) {
    require_once __DIR__ . '/libs/plugin-update-checker/plugin-update-checker.php';

    $cryptoShayanUpdateChecker = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
        $cryptoShayanRepoUrl,
        __FILE__,
        'crypto-shayan'
    );

    // آپدیت رو از روی "Releases" گیت‌هاب بخون (نه صرفاً تگ‌ها) و فایل zip
    // پیوست‌شده به هر ریلیز (مثلاً crypto-shayan-v1.1.0.zip)
    // رو مستقیماً به‌عنوان بسته‌ی نصب استفاده کن.
    $cryptoShayanUpdateChecker->getVcsApi()->enableReleaseAssets();

    // ⚠️ کتابخانه‌ی به‌روزرسان به‌صورت پیش‌فرض فقط ۳ ثانیه صبر می‌کند تا
    // به گیت‌هاب وصل شود. برای هاست‌هایی که مسیر شبکه‌شان تا گیت‌هاب
    // کندتر یا پرتاخیرتر است (مثلاً به دلیل مسیر بین‌المللی طولانی)،
    // همین ۳ ثانیه معمولاً کافی نیست و باعث خطای "Connection timed out"
    // در دکمه‌ی «Check for updates» می‌شود. این مقدار را به ۲۰ ثانیه
    // افزایش می‌دهیم:
    add_filter('puc_request_info_options-crypto-shayan', function($options) {
        $options['timeout'] = 20;
        return $options;
    });

    // اگر مخزن گیت‌هاب Private باشه، یک Personal Access Token با
    // دسترسی خواندن (repo) بذار تا وردپرس بتونه ریلیزها رو ببینه:
    // $cryptoShayanUpdateChecker->setAuthentication('YOUR_GITHUB_TOKEN');
}

require __DIR__ . '/vendor/autoload.php';
new \BeycanPress\CryptoPay\WooCommerce\Loader(__FILE__);
