<?php

namespace BeycanPress\CryptoPay\WooCommerce;

class Loader extends PluginHero\Plugin
{
    public function __construct($pluginFile)
    {
        parent::__construct([
            'pluginFile' => $pluginFile,
            'textDomain' => 'crypto-shayan',
            'pluginKey' => 'crypto_shayan',
            'settingKey' => 'crypto_shayan_settings',
            'pluginVersion' => '1.2.0'
        ]);

        add_action('plugins_loaded', function() {
            new Payment\Register();
        });
        
    }

    public function adminProcess() : void
    {
        new Pages\TransactionList();
        
        add_action('init', function(){
            new Settings;
        }, 9);

        // Load the Vazirmatn font on this plugin's own admin pages only
        // (settings page + transaction list page), so it never affects
        // other plugins' screens.
        add_action('admin_enqueue_scripts', function($hook) {
            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            $screenId = $screen ? $screen->id : '';
            if (strpos($hook, $this->pluginKey) !== false || strpos($screenId, $this->pluginKey) !== false) {
                $this->addStyle('css/crypto-shayan-fonts.css');
            }
        });
    }

    public static function activation() : void
    {
        (new Models\Transaction())->createTable();
    }

    public static function uninstall() : void
    {
        $settings = get_option(self::$instance->settingKey);
        if (isset($settings['dds']) && $settings['dds']) {
            delete_option(self::$instance->settingKey);
            delete_option('woocommerce_'.Payment\Gateways\CryptoWallet::$gateway.'_settings');
            (new Models\Transaction())->drop();
        }
    }
}
