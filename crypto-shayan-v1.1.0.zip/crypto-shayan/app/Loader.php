<?php

namespace BeycanPress\CryptoPay\WooCommerce;

class Loader extends PluginHero\Plugin
{
    public function __construct($pluginFile)
    {
        parent::__construct([
            'pluginFile' => $pluginFile,
            'textDomain' => 'crypto-shayan',
            'pluginKey' => 'crypto_shayan',
            'settingKey' => 'crypto_shayan_settings',
            'pluginVersion' => '1.1.0'
        ]);

        add_action('plugins_loaded', function() {
            new Payment\Register();
        });
        
    }

    public function adminProcess() : void
    {
        new Pages\TransactionList();
        
        add_action('init', function(){
            new Settings;
        }, 9);
    }

    public static function activation() : void
    {
        (new Models\Transaction())->createTable();
    }

    public static function uninstall() : void
    {
        $settings = get_option(self::$instance->settingKey);
        if (isset($settings['dds']) && $settings['dds']) {
            delete_option(self::$instance->settingKey);
            delete_option('woocommerce_'.Payment\Gateways\CryptoWallet::$gateway.'_settings');
            (new Models\Transaction())->drop();
        }
    }
}
