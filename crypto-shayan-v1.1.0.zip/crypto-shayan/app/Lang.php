<?php

namespace BeycanPress\CryptoPay\WooCommerce;

class Lang
{
    public static function get() : array
    {
        return [
            "connect" => esc_html__('Connect wallet', 'crypto-shayan'),
            "notDetected" => esc_html__('The wallet you want to connect to could not be detected!', 'crypto-shayan'),
            "waitingConnection" => esc_html__("Establishing connection please wait!", 'crypto-shayan'),
            "waiting" => esc_html__('Waiting...', 'crypto-shayan'),
            "walletTitle" => esc_html__('Please connect to a wallet to continue', 'crypto-shayan'),
            "connectionRefused" => esc_html__('Connection refused', 'crypto-shayan'),
            "notSupportedChain" => esc_html__('You are currently on an unsupported network, please try again after passing one of the supported networks', 'crypto-shayan'),
            "connectedWallet" => esc_html__('Connected wallet: ', 'crypto-shayan'),
            "activeChain" => esc_html__('Active chain: ', 'crypto-shayan'),
            "connectedAccount" => esc_html__('Connected account: ', 'crypto-shayan'),
            "orderPrice" => esc_html__('Order price: ', 'crypto-shayan'),
            "donateAmount" => esc_html__('Donate amount: ', 'crypto-shayan'),
            "donate" => esc_html__('Donate', 'crypto-shayan'),
            "pleaseEnterDonateAmount" => esc_html__('Please enter donation amount', 'crypto-shayan'),
            "confirmDonate" => esc_html__('Confirm donate', 'crypto-shayan'),
            "donateRejected" => esc_html__('Donate rejected', 'crypto-shayan'),
            "paymentPrice" => esc_html__('Payment price: ', 'crypto-shayan'),
            "paymentCurrency" => esc_html__('Payment currency: ', 'crypto-shayan'),
            "notCurrencySelected" => esc_html__('Not currency selected', 'crypto-shayan'),
            "notCurrencySelectedPay" => esc_html__('Please select the currency you want to pay in', 'crypto-shayan'),
            "notCurrencySelectedDonate" => esc_html__('Please select the currency you want to donate in', 'crypto-shayan'),
            "payWith" => esc_html__('Pay with', 'crypto-shayan'),
            "confirmPayment" => esc_html__('Confirm payment', 'crypto-shayan'),
            "cancel" => esc_html__('Cancel', 'crypto-shayan'),
            "confirm" => esc_html__('Confirm', 'crypto-shayan'),
            "insufficientBalance" => esc_html__('Insufficient balance!', 'crypto-shayan'),
            "paymentRejected" => esc_html__('Payment rejected', 'crypto-shayan'),
            "paymentFailed" => esc_html__('Payment not verified via Blockchain', 'crypto-shayan'),
            "unexpectedError" => esc_html__('An unexpected error has occurred', 'crypto-shayan'),
            "pleaseWait" => esc_html__('Please wait...', 'crypto-shayan'),
            "confirmWithWallet" => esc_html__('Confirm this action in your wallet', 'crypto-shayan'),
            "verifyTransaction" => esc_html__('Awaiting verification of payment via blockchain. Please do not close the page.', 'crypto-shayan'),
            "transactionId" => esc_html__('Transaction Id: ', 'crypto-shayan'),
            "notFoundAcceptedWallets" => esc_html__('No active wallets found, please contact the site administrator.', 'crypto-shayan'),
            "notFoundAcceptedChains" => esc_html__('No active chains found, please contact the site administrator.', 'crypto-shayan'),
            "completedDonate" => esc_html__('Donation sent successfully', 'crypto-shayan'),
            "completedPayment" => esc_html__('Payment completed successfully', 'crypto-shayan'),
            "disconnect" => esc_html__('Disconnect', 'crypto-shayan'),
            'supportedNetworks' => esc_html__('Supported networks', 'crypto-shayan'),
            'problemConvertingCurrency' => esc_html__('There was a problem converting currency!', 'crypto-shayan'),
            'intrinsicGasTooLow' => esc_html__('Intrinsic gas too low', 'crypto-shayan'),
            "chainChanged" => esc_html__("Network change detected page will reload.", 'crypto-shayan'),
            "notAcceptedCurrency" => esc_html__("Not accepted currency", 'crypto-shayan'),
            "timeOut" => esc_html__('The operation timed out, The page will reload.', 'crypto-shayan'),
            "discountRate" => esc_html__("{discountRate}% discount on purchases with this coin.", 'crypto-shayan'),
            "connectionFailed" => esc_html__("There was a problem establishing the connection!", 'crypto-shayan'),
            "notFoundInfuraId" => esc_html__("Infura id is required for WalletConnect", 'crypto-shayan'),
            'alreadyProcessing' => esc_html__("A connection request is already pending, check the wallet plugin!", 'crypto-shayan'),
            'transferAmount' => esc_html__('The transfer amount cannot be less than zero.', 'crypto-shayan')
        ];
    }

}