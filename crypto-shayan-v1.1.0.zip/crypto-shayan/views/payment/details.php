<section class="cryptopay-woocommerce-woocommerce-order-details">
    <h2 class="woocommerce-order-details__title"><?php echo esc_html__('Crypto Shayan payment details', 'crypto-shayan'); ?></h2>
    <table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
        <tr>
            <th scope="row">
                <?php echo esc_html__('Price: ', 'crypto-shayan'); ?>
            </th>
            <td>
                <?php echo esc_html($paymentPrice); ?> <?php echo esc_html($paymentInfo->paymentCurrency); ?>
            </td>
        </tr>
        <?php if (isset($paymentInfo->discountRate)) : ?>
            <tr>
                <th scope="row">
                    <?php echo esc_html__('Discount: ', 'crypto-shayan'); ?>
                </th>
                <td>
                    <?php echo esc_html($paymentInfo->discountRate . ' %'); ?>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <?php echo esc_html__('Real price: ', 'crypto-shayan'); ?>
                </th>
                <td>
                    <?php echo esc_html($paymentInfo->realPrice . " " . $paymentInfo->paymentCurrency); ?>
                </td>
            </tr>
        <?php endif; ?>
        <tr>
            <th scope="row">
                <?php echo esc_html__('Status: ', 'crypto-shayan'); ?>
            </th>
            <td>
                <?php
                    if ($transaction->status == 'pending') {
                        echo esc_html__('Pending', 'crypto-shayan');
                    } elseif ($transaction->status == 'verified') {
                        echo esc_html__('Verified', 'crypto-shayan');
                    } elseif ($transaction->status == 'failed') {
                        echo esc_html__('Failed', 'crypto-shayan');
                    }
                ?>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <?php echo esc_html__('Transaction id: ', 'crypto-shayan'); ?>
            </th>
            <td>
                <?php
                    $explorerUrl = rtrim($paymentInfo->usedChain->explorerUrl, '/');
                ?>
                <a href="<?php echo esc_url($explorerUrl.'/tx/'.$transaction->transaction_id); ?>" target="_blank" style="word-break: break-word">
                    <?php echo esc_html($transaction->transaction_id); ?>
                </a>
            </td>
        </tr>
    </table>
</section>